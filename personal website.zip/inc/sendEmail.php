<?php 

if($_POST) {
    $c_name = trim(stripslashes($_POST['contactEmail']));
    $c_email = trim(stripslashes($_POST['contactEmail']));
    $c_message = trim(stripslashes($_POST['contactMessage']));
    $c_subject = trim(stripslashes($_POST['contactSubject']));
    
    
    
    //$emailId = "povilas.vaitkus@hostinger.com";  // email id where you want ur email to go
    $emailId = "me@shrikrishnaparab.tech";
    $subject = $c_subject;
    
    
    $email_body = "this is the body of the email";
    $from = "me@shrikrishnaparab.tech"; //from email id
    $from_name = "Shrikrishna Parab";  // from name
    
    
    require_once('PHPMailer-master/class.phpmailer.php');
    require_once('PHPMailer-master/class.smtp.php');
    $successful = 0;
    $count1 =0;
    $flag = 0;
    $email = new PHPMailer();
    $email ->IsSMTP();          // set mailer to use SMTP
    $email ->SMTPAuth = true;     // turn on SMTP authentication
    $email ->SMTPSecure = 'ssl';
    $email ->Host = 'smtp.gmail.com';  // specify main and backup server
    $email ->Port = 465;
    
    //$email->IsHTML(true);  // if your email body is a html string
    $email ->Username = "hinterlandgoa@gmail.com";  // SMTP username  real gmail account details 
    $email ->Password = "lnuibkermlbutksf";  // SMTP password gmail
    $email->From      = $from;
    
    $email->FromName  = $from_name;
    $email->Subject   = $subject;
    //$email->Body = "New Contact Details: Name = "+$c_name;
    
    $email->Body      = "New Contact Details: Name = ".$c_name. " Email = ". $c_email." Message = ". $c_message; 
                       
                        
    $email->AddAddress($emailId); 
    $email->AddCC('shrikrishnaparab18@gmail.com');
    //$email->Send();	
    //echo 'Done';
    
    if ($email->Send()) { echo "OK"; }
      else { echo "Something went wrong. Please try again."; }
}